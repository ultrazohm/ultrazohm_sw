/*
 * File Name:         hdl_prj\ipcore\Trans_123_dq_V7_ip_v1_0\include\Trans_123_dq_V7_ip_addr.h
 * Description:       C Header File
 * Created:           2017-02-08 21:28:45
*/

#ifndef TRANS_123_DQ_V7_IP_H_
#define TRANS_123_DQ_V7_IP_H_

#define  IPCore_Reset_Trans_123_dq_V7_ip            0x0  //write 0x1 to bit 0 to reset IP core
#define  IPCore_Enable_Trans_123_dq_V7_ip           0x4  //enabled (by default) when bit 0 is 0x1
#define  theta_offset_AXI_Data_Trans_123_dq_V7_ip   0x100  //data register for port theta_offset_AXI

#endif /* TRANS_123_DQ_V7_IP_H_ */
