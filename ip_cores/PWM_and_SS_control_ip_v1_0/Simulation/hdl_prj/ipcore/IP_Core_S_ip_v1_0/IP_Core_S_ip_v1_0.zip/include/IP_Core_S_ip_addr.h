/*
 * File Name:         hdl_prj\ipcore\IP_Core_S_ip_v1_0\include\IP_Core_S_ip_addr.h
 * Description:       C Header File
 * Created:           2018-10-01 12:51:05
*/

#ifndef IP_CORE_S_IP_H_
#define IP_CORE_S_IP_H_

#define  IPCore_Reset_IP_Core_S_ip                      0x0  //write 0x1 to bit 0 to reset IP core
#define  IPCore_Enable_IP_Core_S_ip                     0x4  //enabled (by default) when bit 0 is 0x1
#define  IPCore_Timestamp_IP_Core_S_ip                  0x8  //contains unique IP timestamp (yymmddHHMM): 1810011250
#define  PWM_en_AXI_Data_IP_Core_S_ip                   0x100  //data register for Inport PWM_en_AXI
#define  Mode_AXI_Data_IP_Core_S_ip                     0x104  //data register for Inport Mode_AXI
#define  PWM_f_carrier_kHz_AXI_Data_IP_Core_S_ip        0x108  //data register for Inport PWM_f_carrier_kHz_AXI
#define  PWM_min_pulse_wiidth_AXI_Data_IP_Core_S_ip     0x10C  //data register for Inport PWM_min_pulse_wiidth_AXI
#define  m_u1_norm_AXI_Data_IP_Core_S_ip                0x110  //data register for Inport m_u1_norm_AXI
#define  m_u2_norm_AXI_Data_IP_Core_S_ip                0x114  //data register for Inport m_u2_norm_AXI
#define  m_u3_norm_AXI_Data_IP_Core_S_ip                0x118  //data register for Inport m_u3_norm_AXI
#define  PWM_en_rd_AXI_Data_IP_Core_S_ip                0x11C  //data register for Outport PWM_en_rd_AXI
#define  PWM_f_carrier_kHz_rd_AXI_Data_IP_Core_S_ip     0x120  //data register for Outport PWM_f_carrier_kHz_rd_AXI
#define  PWM_min_pulse_width_rd_AXI_Data_IP_Core_S_ip   0x124  //data register for Outport PWM_min_pulse_width_rd_AXI
#define  Mode_rd_AXI_Data_IP_Core_S_ip                  0x128  //data register for Outport Mode_rd_AXI

#endif /* IP_CORE_S_IP_H_ */
